<?php
use yii\helpers\Url;





/* @var $this yii\web\View */
$this->title = 'm3profile Intranet';

?>
<div style="min-height: 100%;
  height:auto !important;
  height:100%;" >
<iframe 
style="position:absolute; display:block;width:1070px;height:85%; border: none;" 
src=<?php echo $link; ?>
>
</iframe>
</div>




