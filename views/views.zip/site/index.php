<?php
use yii\helpers\Url;


$link="http://192.168.1.22/m3intra_dev/index.php/vorlagen";


/* @var $this yii\web\View */
$this->title = 'm3profile Intranet';

?>

<!--<iframe
   id="joomla_frame"
   src="http://192.168.1.22/m3intra_dev/index.php/vorlagen"
   frameborder="0"
   width="100%"
   marginheight="0"
   marginwidth="0"
   scrolling="no"
></iframe> -->
<div style="min-height: 100%;
  height:auto !important;
  height:100%;" >
<iframe 
style="position:absolute; display:block;width:1170px;height:85%; border: none; z-index: 500;" 
src=<?php echo $link; ?>
>
</iframe>
</div>




