<?php

use yii\helpers\Html;
use kartik\widgets\ActiveForm;
use kartik\builder\Form;
use kartik\widgets\DatePicker;
use yii\helpers\ArrayHelper;

/* @var $this yii\web\View */
/* @var $model app\models\M3ProjektCheckliste */
/* @var $form yii\widgets\ActiveForm */
?>


<?php
$this->registerJsFile("@web/js/projekt.js",
						['depends' => [\yii\web\JqueryAsset::className()]]
						);


?>

<?php $form = ActiveForm::begin(['type'=>ActiveForm::TYPE_HORIZONTAL, 'formConfig'=>['labelSpan'=>4]]); ?>

<div class="m3-projekt-checkliste-form">
<div class="panel panel-info">
  <div class="panel-heading">Allgemeine Informationen</div>
  <div class="panel-body">
	  
	  <?php
		echo Form::widget([ // fields with labels
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'WerkzeugNr'=>['label'=>'Werkzeug Nr.:', 'options'=>['placeholder'=>'W....']],
				'Kunde'=>['label'=>'Kunde:', 'options'=>['placeholder'=>'Kunde...']],
				'Artikelnummer'=>['label'=>'Artikel Nr.:', 'options'=>['placeholder'=>'Artikel Nr...']],
				'Profilbezeichnung'=>['label'=>'Profilbez.:', 'options'=>['placeholder'=>'Profilbez...']],
				'Projektkoordinator'=>['label'=>'Projekt-Koord..:', 'options'=>['placeholder'=>'Projektkoordination...']],
			]
		]);
		echo Form::widget([
				'model'=>$model,
				'form'=>$form,
				'columns'=>2,
				'attributes'=>[
					'Vorgangsnummer'=>[
								'type'=>Form::INPUT_DROPDOWN_LIST, 
								'items' => ArrayHelper::map($openProjects,'TXTNUMMER','Orderinfo'),
								'label'=>'Vorgangsnr.',
								'options'=>['placeholder'=>'Vorgangsnr...']
							],
					'zeichnungs_detail' => [  
						'label'=>'Zeich.nr./Ind.',
						'labelSpan'=>2,
						'columns'=>4,
						'attributes'=>[
							
							'Zeichnungsnummer'=>[
								'type'=>Form::INPUT_TEXT, 
								'options'=>['placeholder'=>'Zeichnungsnr...'],
								'columnOptions'=>['colspan'=>2],
							],
							'Index'=>[
								'type'=>Form::INPUT_TEXT, 
								'options'=>['placeholder'=>'Index...']
							],
						]
					]
				]
			]);

	  ?>
  </div>
</div>
<div class="panel panel-info">
  <div class="panel-heading">Informationen für Produktion und Technikum</div>
  <div class="panel-body">
	  <?php
		echo Form::widget([ // fields with labels
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'geforderterMindestausstoss'=>['label'=>'geford. Mindestausst. [m/min.]:', 'options'=>['placeholder'=>'Mindestausstoss....']],
				'kalkulierterAusschuss'=>['label'=>'kalk. Ausschuss[%]:', 'options'=>['placeholder'=>'Ausschuss...']],
			]
		]);
		echo Form::widget([ // fields with labels
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'geplanterExtruder'=>['label'=>'geplanter Extruder:', 'options'=>['placeholder'=>'Extruder...']],
				'Einheit'=>['label'=>'Einheit', 'items'=>[0=>'Stück', 1=>'Meter'], 'type'=>Form::INPUT_RADIO_BUTTON_GROUP],
			]
		]);
		?>
			<hr></hr>
			<div class="row">
			  <div class="col-md-2"><label>Gewicht / Bedarfe</label></div>
			  <div class="col-md-4"><label>Art. Nr.</label></div>
			  <div class="col-md-5"><label>Bezeichnung</label></div>
			  <div class="col-md-1"><label>[g/m]</label></div>
			</div>		

		<?php
		echo Form::widget([
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'rohmaterial_detail' => [   // complex nesting of attributes along with labelSpan and colspan
					'label'=>'Kunstst. 1',
					'labelSpan'=>2,
					'columns'=>6,
					'attributes'=>[
						'RM1_Art_Nr'=>[
							'type'=>Form::INPUT_TEXT, 
							'columnOptions'=>['colspan'=>3,'class'=>'col-md-4'],
						],
						'RM1_Bezeichnung'=>[
							'type'=>Form::INPUT_TEXT,
							'columnOptions'=>['colspan'=>2,'class'=>'col-md-6'],
						],
						'RM1_Gewicht'=>[
							'type'=>Form::INPUT_TEXT,  
							'options' => ['id'=>'RM1_Gewicht'],
							'columnOptions'=>['class'=>'col-md-2'],
						]
					]
				],
				'rohmaterial_detail2' => [   // complex nesting of attributes along with labelSpan and colspan
						'label'=>'Kunstst. 2',
						'labelSpan'=>2,
						'columns'=>6,
						'attributes'=>[
								'RM2_Art_Nr'=>[
								'type'=>Form::INPUT_TEXT, 
								'columnOptions'=>['colspan'=>3,'class'=>'col-md-4'],
							],
							'RM2_Bezeichnung'=>[
								'type'=>Form::INPUT_TEXT,
								'columnOptions'=>['colspan'=>2,'class'=>'col-md-6'],
							],
							'RM2_Gewicht'=>[
								'type'=>Form::INPUT_TEXT, 
								'options' => ['id'=>'RM2_Gewicht'], 
								'columnOptions'=>['class'=>'col-md-2'],
							],
						]
					],
				'rohmaterial_detail3' => [   // complex nesting of attributes along with labelSpan and colspan
						'label'=>'Kupfer 1',
						'labelSpan'=>2,
						'columns'=>6,
						'attributes'=>[
								'CU1_Art_Nr'=>[
								'type'=>Form::INPUT_TEXT, 
								'columnOptions'=>['colspan'=>3,'class'=>'col-md-4'],
							],
							'CU1_Bezeichnung'=>[
								'type'=>Form::INPUT_TEXT,
								'columnOptions'=>['colspan'=>2,'class'=>'col-md-6'],
							],
							'CU1_Gewicht'=>[
								'type'=>Form::INPUT_TEXT, 
								'options' => ['id'=>'CU1_Gewicht'], 
								'columnOptions'=>['class'=>'col-md-2'],
							],
						]
					],
				'rohmaterial_detail4' => [   // complex nesting of attributes along with labelSpan and colspan
						'label'=>'Kupfer 2',
						'labelSpan'=>2,
						'columns'=>6,
						'attributes'=>[
								'CU2_Art_Nr'=>[
								'type'=>Form::INPUT_TEXT, 
								'columnOptions'=>['colspan'=>3,'class'=>'col-md-4'],
							],
							'CU2_Bezeichnung'=>[
								'type'=>Form::INPUT_TEXT,
								'columnOptions'=>['colspan'=>2,'class'=>'col-md-6'],
							],
							'CU2_Gewicht'=>[
								'type'=>Form::INPUT_TEXT, 
								'options' => ['id'=>'CU2_Gewicht'],
								'columnOptions'=>['class'=>'col-md-2'],
							],
						]
					]										
			]
		]);

	  ?>
			<div class="row">
			  <div class="col-md-7"></div>
			  <div class="col-md-2"><label>Gewicht ges.:</label></div>
			  <div class="col-md-3">
						<?php	
						echo Form::widget([ 
							'model'=>$model,
							'form'=>$form,
							'columns'=>1,
							'attributes'=>[
								'Gewicht_gesamt'=>['label'=>'', 'options'=>['id'=>'sum','readonly' => true]]
							]
						]);
					  ?>
				</div>
			</div>	
	<?php	
		echo Form::widget([ 
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'Peripherie'=>['label'=>'Peripherie/ Weiterb.:', 'options'=>['placeholder'=>'Peripherie / Weiterbearb.....']]
			]
		]);
	  ?>
  </div>
</div>
<div class="panel panel-info">
  <div class="panel-heading">Auftragsbestätigung an Kunden</div>
  <div class="panel-body">
	  <?php
		echo Form::widget([       // 1 column layout
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'Versandadresse_Muster'=>['type'=>Form::INPUT_TEXTAREA, 'options'=>['placeholder'=>'Versandadresse Muster...']]
			]
		]);
		echo Form::widget([ 
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'Kontaktperson'=>['label'=>'Kontaktperson:', 'options'=>['placeholder'=>'Kontaktperson.....']],
				'Mindestbestellmenge'=>['label'=>'Mindestbestellmenge:','options'=>['placeholder'=>'Mindestbestellmenge....']],
				'Zahlungsbed_Werkzeug'=>['label'=>'Zahlungsbed. Werkz.:', 'options'=>['placeholder'=>'Zahlungsbed. Werkz......']],
				'Lieferbedingungen'=>['label'=>'Lieferbedingungen:', 'items'=>[0=>'DDP', 1=>'EXW'], 'type'=>Form::INPUT_RADIO_BUTTON_GROUP],
			]
		]);
	  ?>		
  </div>
</div>
<div class="panel panel-info">
  <div class="panel-heading">Information für Bemusterung / QS</div>
  <div class="panel-body">
	  <?php
echo Form::widget([ 
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'Muster_Kunde_Anz'=>['label'=>'Anz. Muster f. Kund.:', 'options'=>['placeholder'=>'Anzahl Muster für den Kunden.....'],'columnOptions'=>['class'=>'col-md-7'],],
				'Muster_Kunde_Laenge'=>['label'=>'Länge:','options'=>['placeholder'=>'Länge der Muster für den Kunden....'],'columnOptions'=>['class'=>'col-md-5'],],
				'Muster_Vermess_Anz'=>['label'=>'Anz. Muster zum Verm.:', 'options'=>['placeholder'=>'Anzahl Muster zum Vermessen....'],'columnOptions'=>['class'=>'col-md-7'],],
				'Muster_Vermess_Laenge'=>['label'=>'Länge:','options'=>['placeholder'=>'Länge der Muster zum Vermessen....'],'columnOptions'=>['class'=>'col-md-5'],],
				'Muster_Verbleib_Anz'=>['label'=>'Anz. Muster m3profile.:', 'options'=>['placeholder'=>'Anzahl Muster zum Verbleib bei m3profile....'],'columnOptions'=>['class'=>'col-md-7'],],
				'Muster_Verbleib_Laenge'=>['label'=>'Länge:','options'=>['placeholder'=>'Länge der Muster zum Verbleib bei m3....'],'columnOptions'=>['class'=>'col-md-5'],],
			]
		]);
		echo Form::widget([  
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'sonst_Info_Bemusterung'=>['label'=>'sonstige Infos*:', 'type'=>Form::INPUT_TEXTAREA, 'options'=>['placeholder'=>'sonstige Infos Bemusterung...']],
			]
		]); ?>
		<div class="row"><span class="col-md-12"><small><i>*z.B. 100% Prüfung, kritische funtionsr. Merkmale,FMEA, IMDS, 
							Kugeldruckprüfung, Geruch RPZ-Vorgabe, Kunden EMP, 
							Prüfmittel festlegen, Arbeitsabläufe definieren</i></small></span>
		</div>
		<div class="row"><hr></div>
							
<?php
		echo Form::widget([  
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'Verpackung_Muster'=>['label'=>'Verpackung Musterteile:', 'options'=>['placeholder'=>'Verpackung der Musterteile....']],
				'Verpackung_Serie'=>['label'=>'Verpackung Serienteile:', 'options'=>['placeholder'=>'Verpackung der Serienteile....']],
				'erste_Serien_Menge'=>['label'=>'1. Serienmenge:','options'=>['placeholder'=>'erste Serienbestellung (Menge)....','format'=>'decimal']],
			]
		]);
		echo Form::widget([ 
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'attributes'=>[
				'Verp_stellt_Kunde'=>['label'=>'Verpack. stellt Kunde:', 'items'=>[0=>'Nein', 1=>'Ja'], 'type'=>Form::INPUT_RADIO_BUTTON_GROUP],
				'Verp_zahl_Kunde'=>['label'=>'Verpack. zahlt Kunde:', 'items'=>[0=>'Nein', 1=>'Ja'], 'type'=>Form::INPUT_RADIO_BUTTON_GROUP],
			]
		]);
	  ?>		
  </div>
</div>
<div class="panel panel-info">
  <div class="panel-heading">Information Termine</div>
  <div class="panel-body">
	  <?php

echo Form::widget([ 
			'model'=>$model,
			'form'=>$form,
			'columns'=>2,
			'options'=>[],
			'attributes'=>[
						'Termin_Pruefber_Ende'=>[
						'label'=>false,
						'type'=>Form::INPUT_WIDGET, 
						'widgetClass'=>'\kartik\datecontrol\DateControl',
						'options' => ['widgetOptions'=>['pluginOptions' =>['calendarWeeks' => true, 'autoclose' => true]]],
						'hint'=>'Termin Prüfbericht beim Kunden',
						],
						'Termin_Pruefber_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer Prüfbericht [Wochen]',
						'options' => ['id'=>'Termin_Pruefber_Dauer'],
						],
						'ext_Bem_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_ext_Bem_Ende,'Ende ext. Bem.', 'RAW_ext_Bem_Ende');}
						],
						'Termin_ext_Bem_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer ext. Bemusterung [Wochen]',
						'options' => ['id'=>'Termin_ext_Bem_Dauer'], 
						],
						'int_Bem_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_int_Bem_Ende, 'Ende int. Bem.','RAW_int_Bem_Ende');}
						],
						'Termin_int_Bem_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer int. Bemusterung [Wochen]',
						'options' => ['id'=>'Termin_int_Bem_Dauer'], 
						],
						'vorrichtung_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_Vorrichtung_Ende, 'Ende Vorrichtung','RAW_Vorrichtung_Ende');}
						],
						'Termin_Vorrichtung_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer Vorrichtung [Wochen]',
						'options' => ['id'=>'Termin_Vorrichtung_Dauer'], 
						],
						'Linie_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_Linie_Ende, 'Ende Linie','RAW_Linie_Ende');}
						],
						'Termin_Linie_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer Linie [Wochen]',
						'options' => ['id'=>'Termin_Linie_Dauer'], 
						],
						'RM_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_RM_Ende, 'Ende Rohmat.','RAW_RM_Ende');}
						],
						'Termin_RM_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer Rohm. [Wochen]',
						'options' => ['id'=>'Termin_RM_Dauer'], 
						],
						'WZBau_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_WZBau_Ende, 'Ende WZ.Bau','RAW_WZBau_Ende');}
						],
						'Termin_WZBau_Dauer'=>[
						'label'=>false,
						'hint'=>'Dauer WZ.Bau [Wochen]',
						'options' => ['id'=>'Termin_WZBau_Dauer'], 
						],
						'Konst_Ende' =>[
						'type'=>Form::INPUT_RAW,
						'value' => function($model){return rawTermin($model->Termin_Konst_Ende, 'Ende Konst','RAW_Konst_Ende');}
						],
						'Termin_Konst_Dauer'=>[
						'label'=>false,
						'type'=>Form::INPUT_STATIC,
						'hint'=>'Dauer / Restzeit Kosnst. [Wochen]',
						'options' => ['id'=>'Termin_Konst_Dauer'], 
						],
						'Termin_Konst_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_Konst_Ende'],
						],
						'Termin_WZBau_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_WZBau_Ende'],
						],
						'Termin_RM_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_RM_Ende'],
						],
						'Termin_Linie_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_Linie_Ende'],
						],
						'Termin_Vorrichtung_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_Vorrichtung_Ende'],
						],
						'Termin_int_Bem_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_int_Bem_Ende'],
						#'staticValue'=> 'KW '.date("W-Y",Yii::$app->formatter->asTimestamp($model->Termin_int_Bem_Ende)),
						],
						'Termin_ext_Bem_Ende'=>[
						'type'=>Form::INPUT_HIDDEN,
						'options' => ['id'=>'Termin_ext_Bem_Ende'],
						],
			]
		]);

	  


	  ?>		
  </div>
</div>
<div class="panel panel-info">
  <div class="panel-heading">sonstige Informationen</div>
  <div class="panel-body">
	  <?php
		echo Form::widget([      
			'model'=>$model,
			'form'=>$form,
			'columns'=>1,
			'attributes'=>[
				'sonst_Info_allg'=>['type'=>Form::INPUT_TEXTAREA, 'options'=>['placeholder'=>'sonstige Informationen...']]
			]
		]);
	  ?>		
  </div>
</div>
<div class="panel panel-default">
  <div class="panel-body">
	<div class="col-md-1"></div>	
    <div class="form-group">
        <?= Html::submitButton('Speichern', ['class' => 'btn btn-success']) ?>
    </div>
  </div>
</div>


    <?php ActiveForm::end(); ?>
</div>

<?php 
function rawTermin($date,$label,$id){
	$formdate = Yii::$app->formatter->asDate($date);
	$anzeige = '<div class="form-group">
					<label class="control-label col-md-4">'.$label.'</label>
					<div class="form-control-static" id="'.$id.'">'.$formdate.'</div>
				</div>';
	return $anzeige;
}
?>

