<?php

use yii\helpers\Html;
use kartik\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\ProjektChecklisteSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'm3profile Projekt Übersicht';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="m3-projekt-uebersicht">

  
    <h1>Test</h1>


</div>
